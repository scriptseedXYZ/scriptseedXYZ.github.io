// Before uploading this folder to Cloudflare Pages, replace the value below
// with the public URL copied from your deployed Cloudflare Worker.
window.RESUME_CHAT_WORKER_URL = "PASTE-YOUR-WORKER-URL-HERE";
